PORTFÓLIO — HENRIQUE QUARESMA

1. Abra esta pasta no VS Code.
2. Abra index.html no navegador para visualizar o portfólio.
3. Nos cartões dos projetos, escolha:
   - Visualizar demonstração
   - Ver código-fonte

O GestorPro oferece uma prévia estática para visitantes. O sistema completo em Flask precisa ser executado em um servidor Python.
Os dados, endereço, telefone e preços da Barbearia Prime são fictícios.
Antes de publicar, atualize o e-mail de contato no index.html.
O projeto é demonstrativo e não está preparado para uso comercial em produção.
