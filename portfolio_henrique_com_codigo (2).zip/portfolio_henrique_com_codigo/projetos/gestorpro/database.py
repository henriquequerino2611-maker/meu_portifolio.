import sqlite3

def conectar():
    conexao = sqlite3.connect("gestorpro.db")
    conexao.row_factory = sqlite3.Row
    return conexao

def criar_tabelas():
    db = conectar()
    db.execute("""CREATE TABLE IF NOT EXISTS clientes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nome TEXT NOT NULL,
        email TEXT
    )""")
    db.execute("""CREATE TABLE IF NOT EXISTS produtos (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nome TEXT NOT NULL,
        preco REAL NOT NULL DEFAULT 0,
        estoque INTEGER NOT NULL DEFAULT 0
    )""")
    db.execute("""CREATE TABLE IF NOT EXISTS vendas (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        produto_id INTEGER NOT NULL,
        quantidade INTEGER NOT NULL,
        total REAL NOT NULL,
        FOREIGN KEY (produto_id) REFERENCES produtos(id)
    )""")
    db.commit()
    db.close()
