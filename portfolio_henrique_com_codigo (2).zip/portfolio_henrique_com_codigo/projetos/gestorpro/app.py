from flask import Flask, render_template, request, redirect, url_for
from database import conectar, criar_tabelas

app = Flask(__name__)
criar_tabelas()

@app.route("/")
def inicio():
    db = conectar()
    clientes = db.execute("SELECT COUNT(*) FROM clientes").fetchone()[0]
    produtos = db.execute("SELECT COUNT(*) FROM produtos").fetchone()[0]
    vendas = db.execute("SELECT COUNT(*) FROM vendas").fetchone()[0]
    db.close()
    return render_template("index.html", clientes=clientes, produtos=produtos, vendas=vendas)

@app.route("/clientes", methods=["GET", "POST"])
def clientes():
    db = conectar()
    if request.method == "POST":
        nome = request.form.get("nome", "").strip()
        email = request.form.get("email", "").strip()
        if nome:
            db.execute("INSERT INTO clientes (nome, email) VALUES (?, ?)", (nome, email))
            db.commit()
        db.close()
        return redirect(url_for("clientes"))
    lista = db.execute("SELECT * FROM clientes ORDER BY id DESC").fetchall()
    db.close()
    return render_template("clientes.html", clientes=lista)

@app.route("/produtos", methods=["GET", "POST"])
def produtos():
    db = conectar()
    if request.method == "POST":
        nome = request.form.get("nome", "").strip()
        preco = request.form.get("preco", "0").replace(",", ".")
        estoque = request.form.get("estoque", "0")
        if nome:
            db.execute("INSERT INTO produtos (nome, preco, estoque) VALUES (?, ?, ?)",
                       (nome, float(preco), int(estoque)))
            db.commit()
        db.close()
        return redirect(url_for("produtos"))
    lista = db.execute("SELECT * FROM produtos ORDER BY id DESC").fetchall()
    db.close()
    return render_template("produtos.html", produtos=lista)

@app.route("/vendas", methods=["GET", "POST"])
def vendas():
    db = conectar()
    if request.method == "POST":
        produto_id = request.form.get("produto_id")
        quantidade = int(request.form.get("quantidade", "1"))
        produto = db.execute("SELECT * FROM produtos WHERE id = ?", (produto_id,)).fetchone()
        if produto and quantidade > 0 and produto["estoque"] >= quantidade:
            total = produto["preco"] * quantidade
            db.execute("INSERT INTO vendas (produto_id, quantidade, total) VALUES (?, ?, ?)",
                       (produto_id, quantidade, total))
            db.execute("UPDATE produtos SET estoque = estoque - ? WHERE id = ?",
                       (quantidade, produto_id))
            db.commit()
        db.close()
        return redirect(url_for("vendas"))
    produtos = db.execute("SELECT * FROM produtos ORDER BY nome").fetchall()
    historico = db.execute("""SELECT vendas.id, produtos.nome, vendas.quantidade, vendas.total
                              FROM vendas JOIN produtos ON produtos.id = vendas.produto_id
                              ORDER BY vendas.id DESC""").fetchall()
    db.close()
    return render_template("vendas.html", produtos=produtos, vendas=historico)

if __name__ == "__main__":
    app.run(debug=True)
