Barbearia Prime - projeto demonstrativo em HTML e CSS.
Abra index.html no navegador.
Os dados, endereço, telefone e preços são fictícios e devem ser substituídos se o projeto for adaptado para um negócio real.
